# pyright: reportMissingImports=false
"""
MaixCAM 视觉识别 + 串口通信脚本
- 识别三角形、四边形、椭圆
- 连续 8 帧稳定后通过串口发送给 Arduino
- 串口: UART2 (A28=TX, A29=RX), 9600 baud
"""

from maix import app, camera, display, image, uart, pinmap, time as mtime
import cv2
import numpy as np

# -------- 串口初始化 --------
pinmap.set_pin_function("A28", "UART2_TX")
pinmap.set_pin_function("A29", "UART2_RX")
serial = uart.UART("/dev/ttyS2", 9600)

# -------- 摄像头参数 --------
FRAME_W = 320
FRAME_H = 240

# -------- LAB 阈值（与 jiance.py 一致） --------
L_MIN, L_MAX = 202, 255
A_MIN, A_MAX = 102, 255
B_MIN, B_MAX = 76, 255

# -------- 形状过滤参数（与 jiance.py 一致） --------
MIN_AREA = 700
MAX_AREA = FRAME_W * FRAME_H * 0.85
MIN_W = 20
MIN_H = 20
EDGE_MARGIN = 6
ROI_EDGE_MARGIN = 8
MAX_ASPECT_RATIO = 3.2
POLY_AREA_MIN_RATIO = 0.72
POLY_AREA_MAX_RATIO = 1.18
TRI_AREA_MIN_RATIO = 0.50
TRI_AREA_MAX_RATIO = 1.35

ROI_LEFT_RATIO = 0.25
ROI_RIGHT_RATIO = 0.75

MEDIAN_K = 3
MORPH_K = 3
APPROX_EPS_DETAIL = 0.012
APPROX_EPS = 0.035
APPROX_EPS_STRONG = 0.055
ELLIPSE_MIN_DETAIL_SIDES = 5
ELLIPSE_FILL_MIN = 0.62
ELLIPSE_FILL_MAX = 1.30
ELLIPSE_RECT_EXTENT_MAX = 0.90

# -------- 颜色（RGB） --------
COLOR_RED    = (255, 0, 0)
COLOR_ORANGE = (255, 165, 0)
COLOR_GREEN  = (0, 255, 0)
COLOR_WHITE  = (255, 255, 255)
COLOR_BLACK  = (0, 0, 0)

# -------- 稳定帧数阈值 --------
STABLE_FRAMES_REQUIRED = 8

# -------- 串口发送间隔（ms），避免重复刷屏 --------
SEND_INTERVAL_MS = 500


def find_contours(mask):
    result = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return result[0] if len(result) == 2 else result[1]


def clean_mask(mask, kernel):
    mask = cv2.medianBlur(mask, MEDIAN_K)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return mask


def apply_detect_roi(mask):
    left  = int(FRAME_W * ROI_LEFT_RATIO)
    right = int(FRAME_W * ROI_RIGHT_RATIO)
    mask[:, :left]  = 0
    mask[:, right:] = 0
    return mask


def approx_hull(contour, eps_ratio):
    hull = cv2.convexHull(contour)
    peri = cv2.arcLength(hull, True)
    if peri <= 0:
        return hull, peri
    approx = cv2.approxPolyDP(hull, eps_ratio * peri, True)
    return approx, peri


def contour_center(contour):
    m = cv2.moments(contour)
    if m["m00"] != 0:
        return int(m["m10"] / m["m00"]), int(m["m01"] / m["m00"])
    x, y, w, h = cv2.boundingRect(contour)
    return x + w // 2, y + h // 2


def center_in_detect_roi(contour):
    cx, _ = contour_center(contour)
    left  = int(FRAME_W * ROI_LEFT_RATIO)
    right = int(FRAME_W * ROI_RIGHT_RATIO)
    return left <= cx <= right


def contour_passes_geometry(contour, area):
    x, y, w, h = cv2.boundingRect(contour)
    if w < MIN_W or h < MIN_H:
        return False
    if x <= EDGE_MARGIN or y <= EDGE_MARGIN:
        return False
    if x + w >= FRAME_W - EDGE_MARGIN or y + h >= FRAME_H - EDGE_MARGIN:
        return False
    left  = int(FRAME_W * ROI_LEFT_RATIO)
    right = int(FRAME_W * ROI_RIGHT_RATIO)
    if x <= left + ROI_EDGE_MARGIN or x + w >= right - ROI_EDGE_MARGIN:
        return False
    aspect = max(w, h) / max(1, min(w, h))
    if aspect > MAX_ASPECT_RATIO:
        return False
    rect_area = w * h
    if rect_area <= 0:
        return False
    if area / rect_area < 0.22:
        return False
    return True


def best_polygon_approx(contour):
    best = None
    best_sides = 0
    for eps in (0.025, APPROX_EPS, APPROX_EPS_STRONG, 0.075):
        approx, _ = approx_hull(contour, eps)
        sides = len(approx)
        if sides in (3, 4):
            return approx, sides
        if best is None or abs(sides - 4) < abs(best_sides - 4):
            best = approx
            best_sides = sides
    return best, best_sides


def ellipse_score(contour):
    if len(contour) < 5:
        return 0
    area = cv2.contourArea(contour)
    ellipse = cv2.fitEllipse(contour)
    (_, _), (axis_a, axis_b), _ = ellipse
    if axis_a <= 0 or axis_b <= 0:
        return 0
    ellipse_area = np.pi * (axis_a * 0.5) * (axis_b * 0.5)
    if ellipse_area <= 0:
        return 0
    fill_ratio = area / ellipse_area
    if fill_ratio < ELLIPSE_FILL_MIN or fill_ratio > ELLIPSE_FILL_MAX:
        return 0
    rect = cv2.minAreaRect(contour)
    rect_w, rect_h = rect[1]
    rect_area = rect_w * rect_h
    if rect_area <= 0:
        return 0
    rect_extent = area / rect_area
    if rect_extent > ELLIPSE_RECT_EXTENT_MAX:
        return 0
    return fill_ratio


def classify_shape(contour):
    area = cv2.contourArea(contour)
    if area < MIN_AREA or area > MAX_AREA:
        return None
    if not center_in_detect_roi(contour):
        return None
    if not contour_passes_geometry(contour, area):
        return None
    hull = cv2.convexHull(contour)
    hull_area = cv2.contourArea(hull)
    if hull_area <= 0:
        return None
    solidity = area / hull_area
    if solidity < 0.82:
        return None
    approx_detail, _ = approx_hull(contour, APPROX_EPS_DETAIL)
    detail_sides = len(approx_detail)
    ellipse_like = (detail_sides >= ELLIPSE_MIN_DETAIL_SIDES and ellipse_score(hull) > 0)
    if ellipse_like:
        return {"name": "Ellipse", "side_text": "ellipse", "color": COLOR_GREEN,
                "draw": "ellipse", "contour": hull, "area": area}
    approx, sides = best_polygon_approx(contour)
    if sides == 3:
        poly_area = cv2.contourArea(approx) if approx is not None else 0
        ratio = poly_area / area if area > 0 else 0
        if ratio < TRI_AREA_MIN_RATIO or ratio > TRI_AREA_MAX_RATIO:
            return None
        return {"name": "Triangle", "side_text": "3 sides", "color": COLOR_ORANGE,
                "draw": "poly", "approx": approx, "area": area}
    if sides == 4:
        poly_area = cv2.contourArea(approx) if approx is not None else 0
        ratio = poly_area / area if area > 0 else 0
        if ratio < POLY_AREA_MIN_RATIO or ratio > POLY_AREA_MAX_RATIO:
            return None
        return {"name": "Quadrilateral", "side_text": "4 sides", "color": COLOR_RED,
                "draw": "poly", "approx": approx, "area": area}
    if ellipse_score(hull) > 0 and detail_sides >= ELLIPSE_MIN_DETAIL_SIDES - 1:
        return {"name": "Ellipse", "side_text": "ellipse", "color": COLOR_GREEN,
                "draw": "ellipse", "contour": hull, "area": area}
    return None


def draw_detection(out, det):
    color = det["color"]
    if det["draw"] == "poly":
        cv2.drawContours(out, [det["approx"]], -1, color, 2)
        x, y, w, h = cv2.boundingRect(det["approx"])
    else:
        ellipse = cv2.fitEllipse(det["contour"])
        cv2.ellipse(out, ellipse, color, 2)
        x, y, w, h = cv2.boundingRect(det["contour"])
    cv2.putText(out, det["side_text"], (x, max(14, y - 5)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1, cv2.LINE_AA)


def draw_status(out, name, frame_count):
    text = "{} F:{}".format(name, frame_count)
    cv2.putText(out, text, (5, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.45, COLOR_BLACK, 2)
    cv2.putText(out, text, (5, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.45, COLOR_WHITE, 1)


def draw_roi(out):
    left  = int(FRAME_W * ROI_LEFT_RATIO)
    right = int(FRAME_W * ROI_RIGHT_RATIO)
    cv2.line(out, (left, 0), (left, FRAME_H - 1), (255, 255, 0), 1)
    cv2.line(out, (right, 0), (right, FRAME_H - 1), (255, 255, 0), 1)


def main():
    cam    = camera.Camera(FRAME_W, FRAME_H, image.Format.FMT_RGB888)
    disp   = display.Display()
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (MORPH_K, MORPH_K))

    last_name     = "None"
    stable_frames = 0
    sent_shape    = "None"   # 已发送的形状，避免重复发送
    last_send_ms  = 0

    while not app.need_exit():
        src = cam.read()
        rgb = image.image2cv(src, ensure_bgr=False, copy=True)

        bgr_for_lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        lab = cv2.cvtColor(bgr_for_lab, cv2.COLOR_BGR2LAB)
        mask = cv2.inRange(
            lab,
            np.array([L_MIN, A_MIN, B_MIN], dtype=np.uint8),
            np.array([L_MAX, A_MAX, B_MAX], dtype=np.uint8),
        )
        mask = apply_detect_roi(mask)
        mask = clean_mask(mask, kernel)

        detections = []
        for contour in find_contours(mask):
            det = classify_shape(contour)
            if det is not None:
                detections.append(det)
        detections.sort(key=lambda d: d["area"], reverse=True)

        out = rgb.copy()
        for det in detections:
            draw_detection(out, det)

        if detections:
            current_name = detections[0]["name"]
            if current_name == last_name:
                stable_frames += 1
            else:
                last_name     = current_name
                stable_frames = 1
        else:
            current_name  = "None"
            last_name     = "None"
            stable_frames = 0

        # 连续 8 帧稳定后每 500ms 持续发送
        now_ms = mtime.time_ms()
        if (stable_frames >= STABLE_FRAMES_REQUIRED
                and current_name != "None"
                and now_ms - last_send_ms >= SEND_INTERVAL_MS):
            shape_map = {
                "Triangle":      b"triangle\n",
                "Quadrilateral": b"quadrilateral\n",
                "Ellipse":       b"ellipse\n",
            }
            msg = shape_map.get(current_name)
            if msg:
                serial.write(msg)
                sent_shape   = current_name
                last_send_ms = now_ms

        draw_roi(out)
        draw_status(out, current_name, stable_frames)
        disp.show(image.cv2image(out, bgr=False, copy=False))


if __name__ == "__main__":
    main()
